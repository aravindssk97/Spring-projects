package com.examly.springapp.service;
import java.util.List;
import com.examly.springapp.model.Survey;


public interface SurveyService {
      public Survey insertSurvey(Survey survey);
      public Survey updateSurvey(Survey survey , long id);
      public Survey getSurveyById(long id);
      public List<Survey> getAllSurveys();
      public Boolean deleteSurvey(long id);
      
}
    

