package com.examly.springapp.service;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.examly.springapp.model.Survey;
import com.examly.springapp.repository.SurveyRepository;


@Service
public class SurveyServiceImpl implements SurveyService{
    @Autowired
    private SurveyRepository surveyRepository;

    @Override
    public Survey insertSurvey(Survey survey){
        return surveyRepository.save(survey);
    }
    @Override
    public Survey updateSurvey(Survey survey,long id){
       if(surveyRepository.existsById(id))
          survey.setId(id);
       return surveyRepository.save(survey);
}
  @Override
  public Survey getSurveyById(long id){
    if(surveyRepository.existsById(id))
      return surveyRepository.findById(id).get();
    return null;
  }  

  @Override
  public List<Survey> getAllSurveys(){
    return surveyRepository.findAll();
  }
  @Override
  public Boolean deleteSurvey(long id){
    surveyRepository.deleteById(id);
    return !(surveyRepository.existsById(id));
  }
 

}
