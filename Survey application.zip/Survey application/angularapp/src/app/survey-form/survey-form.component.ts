import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { SurveyService } from '../services/survey.service';

@Component({
  selector: 'app-survey-form',
  templateUrl: './survey-form.component.html',
  styleUrls: ['./survey-form.component.css']
})
export class SurveyFormComponent implements OnInit {
  survey: any = { title: '', description: '' };
  isSavedSuccessfully: boolean = false;  // Declare the property here
  successMessage: string = '';
  editMode: boolean = false;

  constructor(
    private surveyService: SurveyService,
    private route: ActivatedRoute,
    private router: Router
  ) { }

  async ngOnInit(): Promise<void> {
    const id = this.route.snapshot.paramMap.get('id');
    if (id) {
      this.editMode = true;
      try {
        this.survey = await this.surveyService.getSurveyById(+id);
      } catch (error) {
        console.error('Error fetching survey', error);
      }
    }
  }

  async save(): Promise<void> {
    try {
      if (this.survey.id) {
        await this.surveyService.updateSurvey(this.survey.id, this.survey);
        this.successMessage = 'Survey updated successfully!';  // Edit mode success message
      } else {
        await this.surveyService.createSurvey(this.survey);
        this.successMessage = 'Survey created successfully!';  // Create mode success message
      }
      // Hide the success message after 2 seconds and navigate back to the surveys list
      setTimeout(() => {
        this.successMessage = '';  // Clear success message
        this.router.navigate(['/surveys']);
      }, 2000);

    } catch (error) {
      console.error('Error saving survey', error);
    }
  }
}