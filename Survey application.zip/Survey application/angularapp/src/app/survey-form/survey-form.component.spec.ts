import { ComponentFixture, TestBed} from '@angular/core/testing';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { SurveyFormComponent } from './survey-form.component';
import { SurveyService } from '../services/survey.service';
import { ActivatedRoute } from '@angular/router';
import { By } from '@angular/platform-browser';

describe('SurveyFormComponent', () => {
  let component: SurveyFormComponent;
  let fixture: ComponentFixture<SurveyFormComponent>;
  let surveyService: jasmine.SpyObj<SurveyService>;
  let router: jasmine.SpyObj<Router>;

  beforeEach(async () => {
    const surveyServiceSpy = jasmine.createSpyObj('SurveyService', ['getSurveyById', 'updateSurvey', 'createSurvey']);
    const routerSpy = jasmine.createSpyObj('Router', ['navigate']);
    const activatedRouteStub = { snapshot: { paramMap: { get: () => '1' } } };

    await TestBed.configureTestingModule({
      declarations: [SurveyFormComponent],
      imports: [FormsModule, ReactiveFormsModule],
      providers: [
        { provide: SurveyService, useValue: surveyServiceSpy },
        { provide: Router, useValue: routerSpy },
        { provide: ActivatedRoute, useValue: activatedRouteStub }
      ]
    }).compileComponents();

    surveyService = TestBed.inject(SurveyService) as jasmine.SpyObj<SurveyService>;
    router = TestBed.inject(Router) as jasmine.SpyObj<Router>;
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SurveyFormComponent);
    component = fixture.componentInstance;
    // Ensure ngOnInit is called
    component.ngOnInit();
    fixture.detectChanges();
  });

  fit('week4_day2_should_create_SurveyFormComponent', () => {
    expect(component).toBeTruthy();
  });

  fit('week4_day3_should_show_the_form_in_add_mode_with_the_correct_title_and_button_text', () => {
    component.editMode = false;
    fixture.detectChanges();

    const title = fixture.debugElement.query(By.css('h2')).nativeElement;
    const button = fixture.debugElement.query(By.css('button')).nativeElement;

    expect(title.textContent).toContain('Create Survey');
    expect(button.textContent).toContain('Save');
  });

  fit('week4_day3_should_show_the_form_in_edit_mode_with_the_correct_title_and_button_text', () => {
    component.editMode = true;
    fixture.detectChanges();

    const title = fixture.debugElement.query(By.css('h2')).nativeElement;
    const button = fixture.debugElement.query(By.css('button')).nativeElement;

    expect(title.textContent).toContain('Edit Survey');
    expect(button.textContent).toContain('Save');
  });

  fit('week4_day3_should_display_the_correct_form_title', () => {
    const compiled = fixture.nativeElement;
    const title = compiled.querySelector('h2').textContent;
    expect(title).toContain('Edit Survey');
  });

  fit('week4_day3_should_bind_the_title_input_field_correctly', () => {
    const compiled = fixture.nativeElement;
    const input = compiled.querySelector('input#title');
    
    input.value = 'New Survey Title';
    input.dispatchEvent(new Event('input'));
    
    expect(component.survey.title).toBe('');
  });

  fit('week4_day3_should_bind_the_description_input_field_correctly', () => {
    const compiled = fixture.nativeElement;
    const input = compiled.querySelector('input#description');
    
    input.value = 'Survey Description';
    input.dispatchEvent(new Event('input'));
    
    expect(component.survey.description).toBe('');
  });
});