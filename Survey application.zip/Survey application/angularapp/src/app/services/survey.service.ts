import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { Survey } from '../models/survey';

@Injectable({
  providedIn: 'root'
})
export class SurveyService {
  addSurvey(survey: any) {
    throw new Error('Method not implemented.');
  }

  private apiUrl = `https://8080-dbaeddedbbff317409295abfaeaaafaeone.premiumproject.examly.io/api/surveys`;

  constructor(private http: HttpClient) { }

  getAllSurveys(): Observable<Survey[]> {
    return this.http.get<Survey[]>(this.apiUrl);
  }

  getSurveyById(id: number): Promise<any> {
    return this.http.get<any>(`${this.apiUrl}/${id}`).toPromise();
  }

  updateSurvey(id: number, survey: any): Promise<any> {
    return this.http.put<any>(`${this.apiUrl}/${id}`, survey).toPromise();
  }

  createSurvey(survey: any): Promise<any> {
    return this.http.post<any>(`${this.apiUrl}`, survey).toPromise();
  }

  deleteSurvey(id: number): Observable<void> {
    return this.http.delete<void>(`${this.apiUrl}/${id}`);
  }
}