import { TestBed } from '@angular/core/testing';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { SurveyService } from './survey.service';
import { Survey } from '../models/survey';

describe('SurveyService', () => {
  let service: SurveyService;
  let httpTestingController: HttpTestingController;

  // Define mock data for surveys
  const mockSurveys: Survey[] = [
    {
      id: 1,
      title: 'Customer Satisfaction Survey',
      description: 'A survey to measure customer satisfaction.',
    },
    {
      id: 2,
      title: 'Employee Engagement Survey',
      description: 'A survey to gauge employee engagement levels.',
    },
  ];

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [SurveyService],
    });
    service = TestBed.inject(SurveyService);
    httpTestingController = TestBed.inject(HttpTestingController);
  });

  afterEach(() => {
    // Ensure that there are no outstanding requests after each test
    httpTestingController.verify();
  });

  fit('week4_day4_should_create_the_survey_service', () => {
    expect(service).toBeTruthy();
  });

  fit('week4_day4_should_retrieve_all_surveys_from_the_API_via_GET', () => {
    service.getAllSurveys().subscribe((surveys: Survey[]) => {
      expect(surveys).toEqual(mockSurveys);
    });

    const req = httpTestingController.expectOne(service['apiUrl']);
    expect(req.request.method).toBe('GET');
    req.flush(mockSurveys);
  });


  fit('week4_day4_should_create_a_new_survey_via_POST', () => {
    const newSurvey: Survey = {
      id: 3,
      title: 'New Product Feedback Survey',
      description: 'A survey to gather feedback on a new product.',
    };

    service.createSurvey(newSurvey).then((survey) => {
      expect(survey).toEqual(newSurvey);
    });

    const req = httpTestingController.expectOne(service['apiUrl']);
    expect(req.request.method).toBe('POST');
    req.flush(newSurvey);
  });


  fit('week4_day4_should_delete_a_survey_via_DELETE', () => {
    const surveyId = 1;

    service.deleteSurvey(surveyId).subscribe(() => {
      // Additional expectations can be added here if needed
    });

    const req = httpTestingController.expectOne(`${service['apiUrl']}/${surveyId}`);
    expect(req.request.method).toBe('DELETE');
    req.flush({});
  });
});
