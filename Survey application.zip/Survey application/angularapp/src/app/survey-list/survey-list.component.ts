import { Component, OnInit } from '@angular/core';
import { Survey } from '../models/survey';
import { SurveyService } from '../services/survey.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-survey-list',
  templateUrl: './survey-list.component.html',
  styleUrls: ['./survey-list.component.css']
})
export class SurveyListComponent implements OnInit {

  surveys:Survey[]=[];
  constructor(private service:SurveyService,private router:Router) { }

  ngOnInit(): void {
    this.getAlllSurveys();    
  }

  getAlllSurveys(){
    this.service.getAllSurveys().subscribe(data=>{
      this.surveys=data;
      console.log("list init"+JSON.stringify(this.surveys))
    });
  }

  editSurvey(ob:Survey){
    console.log("editSurvey: "+ob.description);
    this.router.navigate(['/survey',{mydata:JSON.stringify(ob)}]);
   // this.router.navigate(['/survey'],{queryParams: {id: ob.id,title: ob.title, description: ob.description }});
  }

  deleteSurvey(id:number){
    this.service.deleteSurvey(id).subscribe(x=>{
      console.log('deleted '+x)
      this.getAlllSurveys();
    });
  }
}