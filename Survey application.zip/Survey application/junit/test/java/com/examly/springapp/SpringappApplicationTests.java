package com.examly.springapp;

import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.fail;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import java.io.File;
import java.lang.reflect.Method;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.TestMethodOrder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.jpa.repository.Query;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
 
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import java.lang.reflect.Field;

@SpringBootTest(classes = SpringappApplication.class)
@AutoConfigureMockMvc
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
class SpringappApplicationTests {

    @Autowired
    private MockMvc mockMvc;

    @Test
    @Order(1)
    public void week3_day2_testControllerFolder() {
        String directoryPath = "src/main/java/com/examly/springapp/controller";
        File directory = new File(directoryPath);
        assertTrue(directory.exists() && directory.isDirectory());
    }

    @Test
    @Order(2)
    public void week3_day2_testSurveyControllerFile() {
        String filePath = "src/main/java/com/examly/springapp/controller/SurveyController.java";
        File file = new File(filePath);
        assertTrue(file.exists() && file.isFile());
    }


    @Test
    @Order(3)
    public void week3_day2_testModelFolder() {
        String directoryPath = "src/main/java/com/examly/springapp/model";
        File directory = new File(directoryPath);
        assertTrue(directory.exists() && directory.isDirectory());
    }

    @Test
    @Order(4)
    public void week3_day2_testSurveyModelFile() {
        String filePath = "src/main/java/com/examly/springapp/model/Survey.java";
        File file = new File(filePath);
        assertTrue(file.exists() && file.isFile());
    }


    


    @Test
    @Order(5)
    public void week3_day2_testServiceFolder() {
        String directoryPath = "src/main/java/com/examly/springapp/service";
        File directory = new File(directoryPath);
        assertTrue(directory.exists() && directory.isDirectory());
    }

    @Test
    @Order(6)
    public void week3_day2_testSurveyServiceFile() {
        String filePath = "src/main/java/com/examly/springapp/service/SurveyService.java";
        File file = new File(filePath);
        assertTrue(file.exists() && file.isFile());
    }

    @Test
    @Order(7)
    public void week3_day3_testRepositoryFolder() {
        String directoryPath = "src/main/java/com/examly/springapp/repository";
        File directory = new File(directoryPath);
        assertTrue(directory.exists() && directory.isDirectory());
    }

    @Test
    @Order(8)
    public void week3_day3_testSurveyRepositoryFile() {
        String filePath = "src/main/java/com/examly/springapp/repository/SurveyRepository.java";
        // Replace with the path to your file
        File file = new File(filePath);
        assertTrue(file.exists() && file.isFile());
    }

    @Test
    @Order(9)
    void week3_day4_testAddSurvey() throws Exception {
        String surveyJson = "{ \"title\": \"Customer Satisfaction\", \"description\": \"Survey to assess customer satisfaction.\" }";
 
        mockMvc.perform(MockMvcRequestBuilders.post("/survey")
                .contentType(MediaType.APPLICATION_JSON)
                .content(surveyJson)
                .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.title").value("Customer Satisfaction"))
                .andExpect(jsonPath("$.description").value("Survey to assess customer satisfaction."))
                .andReturn();
    }

    @Test
    @Order(10)
    void week3_day4_testGetAllSurveys() throws Exception {
        mockMvc.perform(MockMvcRequestBuilders.get("/survey")
                .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[?(@.title == 'Customer Satisfaction')]").exists());
    }
 
 
    @Test
    @Order(11)
    void week3_day5_testGetSurveyById() throws Exception {
        mockMvc.perform(MockMvcRequestBuilders.get("/survey/1")
                .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(1))
                .andExpect(jsonPath("$.title").value("Customer Satisfaction"))
                .andExpect(jsonPath("$.description").value("Survey to assess customer satisfaction."));
    }
 
 
    @Test
    @Order(12)
    void week3_day5_testUpdateSurvey() throws Exception {
        String updatedSurveyJson = "{ \"id\": 1, \"title\": \"Product Feedback\", \"description\": \"Survey to collect product feedback.\" }";
 
        mockMvc.perform(MockMvcRequestBuilders.put("/survey/1")
                .contentType(MediaType.APPLICATION_JSON)
                .content(updatedSurveyJson)
                .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.title").value("Product Feedback"))
                .andExpect(jsonPath("$.description").value("Survey to collect product feedback."));
    }
 
    @Test
    @Order(13)
    void week3_day5_testDeleteSurvey() throws Exception {
        mockMvc.perform(MockMvcRequestBuilders.delete("/survey/1"))
                .andExpect(status().isOk());
                // .andExpect(jsonPath("$").value("Survey 1 deleted successfully"));
    }
    
}
