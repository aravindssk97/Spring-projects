#!/bin/bash
export CHROME_BIN=/usr/bin/chromium
if [ ! -d "/home/coder/project/workspace/angularapp" ]
then
    cp -r /home/coder/project/workspace/karma/angularapp /home/coder/project/workspace/;
fi

if [ -d "/home/coder/project/workspace/angularapp" ]
then
    echo "project folder present"
    cp /home/coder/project/workspace/karma/karma.conf.js /home/coder/project/workspace/angularapp/karma.conf.js;

    # checking for app-routing component
    if [ -d "/home/coder/project/workspace/angularapp/src/app/routing" ]
    then
        cp /home/coder/project/workspace/karma/app-routing.module.spec.ts /home/coder/project/workspace/angularapp/src/app/routing/app-routing.module.spec.ts;
    else
        echo "Frontend_day29_should route to admin page FAILED";
        echo "Frontend_day29_should route to organizer page FAILED";
    fi

   # checking for Home Component 
    if [ -d "/home/coder/project/workspace/angularapp/src/app/team" ]
    then
        cp /home/coder/project/workspace/karma/home.component.spec.ts /home/coder/project/workspace/angularapp/src/app/home/home.component.spec.ts;
    else
        echo "Frontend_day25_should_create_HomeComponent FAILED";
    fi

    # checking for login component
    if [ -d "/home/coder/project/workspace/angularapp/src/app/login" ]
    then
        cp /home/coder/project/workspace/karma/login.component.spec.ts /home/coder/project/workspace/angularapp/src/app/login/login.component.spec.ts;
    else
        echo "Frontend_day31_call_login_method_on_login FAILED";
    fi

    # # checking for admin-services component
    if [ -d "/home/coder/project/workspace/angularapp/src/app/services" ]
    then
        cp /home/coder/project/workspace/karma/admin.service.spec.ts /home/coder/project/workspace/angularapp/src/app/services/admin.service.spec.ts;
    else
        echo "Frontend_day30_should create the admin service FAILED";
    fi


    # checking for auth-services component
     if [ -d "/home/coder/project/workspace/angularapp/src/app/services" ]
     then
         cp /home/coder/project/workspace/karma/auth.service.spec.ts /home/coder/project/workspace/angularapp/src/app/services/auth.service.spec.ts;
     else
        echo "Frontend_day30_should create the auth service FAILED";
     fi


    # checking for organizer-services component
    if [ -d "/home/coder/project/workspace/angularapp/src/app/services" ]
    then
        cp /home/coder/project/workspace/karma/organizer.service.spec.ts /home/coder/project/workspace/angularapp/src/app/services/organizer.service.spec.ts;
    else
        echo "Frontend_day30_should create the organizer service FAILED";
    fi


    # # checking for registrations component
    if [ -d "/home/coder/project/workspace/angularapp/src/app/registration" ]
    then
        cp /home/coder/project/workspace/karma/registration.component.spec.ts /home/coder/project/workspace/angularapp/src/app/registration/registration.component.spec.ts;
    else
        echo "Frontend_day31_should show username required error message on register page FAILED";
        echo "Frontend_day31_should show password required error message on register page FAILED";
    fi



    # checking for PlayerModel 
    if [ -d "/home/coder/project/workspace/angularapp/src/models" ]
    then
        cp /home/coder/project/workspace/karma/player.model.spec.ts /home/coder/project/workspace/angularapp/src/models/player.model.spec.ts;
    else
        echo "Frontend_day24_should_create_Player_instance FAILED";
    fi 

    
     # checking for Team Component 
    if [ -d "/home/coder/project/workspace/angularapp/src/app/team" ]
    then
        cp /home/coder/project/workspace/karma/team.component.spec.ts /home/coder/project/workspace/angularapp/src/app/team/team.component.spec.ts;
    else
        echo "Frontend_day26_create_Team_Component with teams array FAILED";
    fi

     # checking for Player Component 
    if [ -d "/home/coder/project/workspace/angularapp/src/app/team" ]
    then
        cp /home/coder/project/workspace/karma/player.component.spec.ts /home/coder/project/workspace/angularapp/src/app/player/player.component.spec.ts;
    else
        echo "Frontend_day27_should create PlayerComponent with player array FAILED";
    fi


     # checking for Admin Component 
    if [ -d "/home/coder/project/workspace/angularapp/src/app/team" ]
    then
        cp /home/coder/project/workspace/karma/admin.component.spec.ts /home/coder/project/workspace/angularapp/src/app/admin/admin.component.spec.ts;
    else
        echo "Frontend_day26_should have teams and players arrays declared FAILED";
    fi

     # checking for Organizer Component 
    if [ -d "/home/coder/project/workspace/angularapp/src/app/team" ]
    then
        cp /home/coder/project/workspace/karma/organizer.component.spec.ts /home/coder/project/workspace/angularapp/src/app/organizer/organizer.component.spec.ts;
    else
        echo "Frontend_day28_should create the OrganizerComponent with teams array";
    fi


    # checking for TeamModel 
    if [ -d "/home/coder/project/workspace/angularapp/src/models" ]
    then
        cp /home/coder/project/workspace/karma/team.model.spec.ts /home/coder/project/workspace/angularapp/src/models/team.model.spec.ts;
    else
        echo "Frontend_day24_should_create_Team_instance FAILED";
    fi 

    if [ -d "/home/coder/project/workspace/angularapp/node_modules" ]; then
        cd /home/coder/project/workspace/angularapp/
        npm test;
    else
        cd /home/coder/project/workspace/angularapp/
        yes | npm install
        npm test
    fi

else   
     echo "Frontend_day29_should route to admin page FAILED";
     echo "Frontend_day29_should route to organizer page FAILED";
     echo "Frontend_day25_should_create_HomeComponent FAILED";
     echo "Frontend_day31_call_login_method_on_login FAILED";
     echo "Frontend_day31_should show username required error message on register page FAILED";
     echo "Frontend_day31_should show password required error message on register page FAILED";
     echo "Frontend_day24_should_create_Player_instance FAILED";
     echo "Frontend_day26_create_Team_Component with teams array FAILED";
     echo "Frontend_day28_should create the OrganizerComponent with teams array FAILED";
     echo "Frontend_day24_should_create_Team_instance FAILED";
     echo "Frontend_day27_should create PlayerComponent with player array FAILED";
     echo "Frontend_day26_should have teams and players arrays declared FAILED";
     echo "Frontend_day30_should create the auth service FAILED";
     echo "Frontend_day30_should create the admin service FAILED";
     echo "Frontend_day30_should create the organizer service FAILED";
     
fi
