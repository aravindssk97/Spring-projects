package com.examly.springapp.service.serviceImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.examly.springapp.entity.Player;
import com.examly.springapp.entity.Team;
import com.examly.springapp.repository.PlayerRepo;
import com.examly.springapp.repository.TeamRepo;
import com.examly.springapp.service.OrganizerService;

@Service
public class OrganizerServicesImpl implements OrganizerService {
    @Autowired
    private PlayerRepo prepo;
    @Autowired
    private TeamRepo trepo;

    @Override
    public boolean assignPlayerToTeam(Long playerId, Long teamId) {
        if (prepo.existsById(playerId) && trepo.existsById(teamId)) {
            Player p = prepo.findById(playerId).get();
            Team t = trepo.findById(teamId).get();

            System.out.println("Team Current Budget: " + t.getCurrentBudget());
            System.out.println("Player Bidding Price: " + p.getBiddingPrice());

            if (t.getCurrentBudget() < p.getBiddingPrice()) {
                throw new RuntimeException("Exceeds team budget");
            }

            t.addPlayer(p);   //add the player to the team
            p.setSold(true);  //player is added to the team
            p.setTeam(t);      //manytoOne setting the player to team
            t.setCurrentBudget(t.getCurrentBudget() - p.getBiddingPrice());
            prepo.save(p);
            trepo.save(t);

            System.out.println("Player assigned successfully");
            return true;
        }
        System.out.println("Player or Team not found");
        return false;
    }

    @Override
    public List<Player> getPlayerListByTeamId(long teamId) {
        if (trepo.existsById(teamId)) {
            return prepo.findByTeamId(teamId);
        }
        return null;
    }

    @Override
    public List<Player> getSoldPlayers() {
        return prepo.findBySoldTrue();
    }

    @Override
    public List<Player> getUnsoldPlayers() {
        return prepo.findBySoldFalse();
    }

    @Override
    public boolean releasePlayerFromTeam(Long playerId) {
        if (prepo.existsById(playerId)) {
            Player p = prepo.findById(playerId).get();
            Team t = p.getTeam();

            if (t != null) {
                System.out.println("Releasing player: " + p.getName());
                System.out.println("Team Current Budget before release: " + t.getCurrentBudget());
                t.setCurrentBudget(t.getCurrentBudget() + p.getBiddingPrice());
                System.out.println("Team Current Budget after release: " + t.getCurrentBudget());
                p.setTeam(null);
                p.setSold(false);
                prepo.save(p);
                trepo.save(t);
            }

            return true;
        }
        return false;
    }

    public List<Player> getDataByCategory(String category) {
        if (category.equals("All")) {
            return prepo.findAll();
        } else {
            return prepo.findByCategory(category);
        }
    }

    public List<Team> getAllTeams() {
        return trepo.findAll();
    }
}