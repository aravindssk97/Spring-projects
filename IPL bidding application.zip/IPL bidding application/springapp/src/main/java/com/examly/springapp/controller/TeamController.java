package com.examly.springapp.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.examly.springapp.entity.Team;
import com.examly.springapp.service.serviceImpl.TeamServiceImpl;

@RestController
@CrossOrigin
public class TeamController {
    @Autowired
    private TeamServiceImpl service;

    @PostMapping("api/team")
    public ResponseEntity<Team> addTeam(@RequestBody Team team){
        Team t = service.addTeam(team);
        if(t!=null){
            return new ResponseEntity<>(t,HttpStatus.OK);
        }else{
            return new ResponseEntity<>(t,HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PutMapping("api/team/{teamId}")
    public ResponseEntity<Team> updateTeam(@RequestBody Team team, @PathVariable long teamId){
        team.setId(teamId);
        Team t = service.updateById(team);
        if(t!=null){
            return new ResponseEntity<>(team,HttpStatus.OK);
        }else{
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }

    }

    @GetMapping("api/team")
    public List<Team> getAll(){
        List<Team> list = service.getAll();
            if(list.size()>0){
                return list;
            }else{
                return null;
            }
    }

    @GetMapping("api/team/{teamId}")
    public Team getById(@PathVariable long teamId){
        Team t = service.getById(teamId);
            if(t!=null){
                return t;
            }else{
                return null;
            }
    }

    @DeleteMapping("api/team/{teamId}")
    public Boolean deleteById(@PathVariable long teamId){
        boolean b = service.deleteById(teamId);
            if(b){
                return true;
            }else{
                return false;
            }
    }

}
