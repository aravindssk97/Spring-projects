package com.examly.springapp.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.examly.springapp.entity.Player;
import com.examly.springapp.service.PlayerService;

@RestController
@CrossOrigin(allowedHeaders = "*",origins = "*")
public class PlayerController {

    @Autowired
    private PlayerService playerService;

    @PostMapping("api/player")
    public Player addPlayer(@RequestBody Player p){
        Player player = playerService.addPlayer(p);
        if(player!=null){
            return player;
        }
        return null;
    }

    @GetMapping("api/player")
    public List<Player> getPlayer(){
        List<Player> list = playerService.getAllPlayer();
        if(list.size()>0){
            return list;
        }
            return null;
    }

    @GetMapping("api/player/{playerId}")
    public Player getById(@PathVariable long playerId){
        Player p = playerService.getById(playerId);
        if(p!=null){
            return p;
        }
        return null;
    }

    @DeleteMapping("api/player/{playerId}")
    public Boolean deleteById(@PathVariable long playerId){
        Boolean b = playerService.deleteById(playerId);
        if(b){
            return true;
        }
        return false;
    }

    @PutMapping("api/player/{playerId}")
    public Player updatePlayer(@RequestBody Player p,@PathVariable long playerId){
            Player play = playerService.updatePlayerById(p, playerId);
            if(play!=null){
                return p;
            }
            return null;
    }
    
}
