package com.examly.springapp.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.examly.springapp.entity.Team;

@Service
public interface TeamService {

    Team addTeam(Team team);
    Team updateById(Team team);
    List<Team> getAll();
    Team getById(long teamId);
    Boolean deleteById(long teamId);
    
}
