export interface AssignPlayer {
    playerId?:number
    teamId?:number
}
