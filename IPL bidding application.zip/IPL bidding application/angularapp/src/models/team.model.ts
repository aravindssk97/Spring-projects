export interface Team{
    id?:number
    name?:string
    maximumBudget?:number
}