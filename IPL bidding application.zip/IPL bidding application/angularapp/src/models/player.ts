import { Team } from "./team";

export interface Player {
    id ?: number;
    name ?: string;
    age ?: number;
    category ?: string;
    biddingPrice ?: number;
    selectedTeamId ?:number
    sold ?: boolean
    team ?: Team
}
