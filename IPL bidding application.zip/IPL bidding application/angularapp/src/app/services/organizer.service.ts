import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Player } from 'src/models/player.model';
import { Team } from 'src/models/team.model';

@Injectable({
  providedIn: 'root'
})
export class OrganizerService {
  private baseUrl = 'https://8080-ffcfaafecf316719931eabbabbfone.premiumproject.examly.io';

  constructor(private httpClient: HttpClient) { }

  public getUnsoldPlayers(): Observable<Player[]> {
    return this.httpClient.get<Player[]>(`${this.baseUrl}/api/organizer/unsold-players`);
  }

  public getPlayersByCategory(category: string): Observable<Player[]> {
    return this.httpClient.get<Player[]>(`${this.baseUrl}/api/organizer/player-list/category/${category}`);
  }

  public assignPlayerToTeam(teamId: number, playerId: number): Observable<any> {
    return this.httpClient.post(`${this.baseUrl}/api/organizer/assign-player`, null, {
      params: { teamId: teamId.toString(), playerId: playerId.toString() }
    });
  }

  public releasePlayerFromTeam(playerId: number): Observable<any> {
    return this.httpClient.put(`${this.baseUrl}/api/organizer/release-player/${playerId}`, null);
  }

  public getAllTeams(): Observable<Team[]> {
    return this.httpClient.get<Team[]>(`${this.baseUrl}/api/organizer/team-list`);
  }

  public getPlayerByTeamId(teamId: number): Observable<Player[]> {
    return this.httpClient.get<Player[]>(`${this.baseUrl}/api/organizer/player-list/${teamId}`);
  }
}