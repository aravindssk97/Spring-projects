import { HttpClient } from '@angular/common/http';
import { Injectable, OnInit } from '@angular/core';
import { BehaviorSubject, Observable, of } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AuthService implements OnInit {
  private currentUserSubject: BehaviorSubject<string | null>;
  public currentUser: Observable<string | null>;
  private baseUrl = 'https://8080-ffcfaafecf316719931eabbabbfone.premiumproject.examly.io';
  private userRoleSubject = new BehaviorSubject<string>('');
  userRole$: Observable<string> = this.userRoleSubject.asObservable();
  private isAuthenticatedSubject: BehaviorSubject<boolean> = new BehaviorSubject<boolean>(this.isAuthenticated());
  isAuthenticated$ = this.isAuthenticatedSubject.asObservable();

  registeredUsers: any[] = [];

  constructor(private http: HttpClient) {
    this.currentUserSubject = new BehaviorSubject<string | null>(
      localStorage.getItem('currentUser')
    );
    this.currentUser = this.currentUserSubject.asObservable();
  }

  ngOnInit(): void {
    const localdata = localStorage.getItem('registeredUsers');
    if (localdata != null) {
      this.registeredUsers = JSON.parse(localdata);
    }
  }

  register(username: string, password: string, role: string): object {
    const body: object = { username, password, role };
    this.registeredUsers.push(body);

    localStorage.setItem('registeredUsers', JSON.stringify(this.registeredUsers));
    return body;
  }

  login(username: string, password: string, role: string): boolean {
 
    const loginData = { username, password, role };

    const isUserExist = this.registeredUsers.find(u => u.username === loginData.username && u.password === loginData.password && u.role === loginData.role);
    
    if (isUserExist) {
      localStorage.setItem('currentUser', username);
      localStorage.setItem('role', role);
      this.currentUserSubject.next(username);
      this.userRoleSubject.next(role);
      this.isAuthenticatedSubject.next(true);
      return true;
    } else {
      return false;
    }
  }

  isLoggedIn(): boolean {
    console.log(localStorage.getItem('role'));
    return !!localStorage.getItem('role');
  }

  getUserRole(): string | null {
    return localStorage.getItem('role');
  }

  private handleError<T>(operation = 'operation', result?: T) {
    return (error: any): Observable<T> => {
      console.error(error);
      return of(result as T);
    };
  }

  logout(): void {
    localStorage.removeItem('token');
    localStorage.removeItem('currentUser');
    localStorage.removeItem('role');
    this.currentUserSubject.next(null);
    this.userRoleSubject.next('');
    this.isAuthenticatedSubject.next(false);
  }

  isAuthenticated(): boolean {
    const token = localStorage.getItem('role');
    console.log(token);
    return !!token;
  }

  isAdmin(): boolean {
    const token = localStorage.getItem('role');
    console.log(token);
    return token === 'ADMIN';
  }

  isOrganizer(): boolean {
    const token = localStorage.getItem('role');
    if (token === 'ORGANIZER') {
      console.log("token:" + token);
      return true;
    }
    return false;
  }
}