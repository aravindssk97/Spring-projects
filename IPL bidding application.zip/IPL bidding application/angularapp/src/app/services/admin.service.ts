import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Player } from 'src/models/player.model';
import { Team } from 'src/models/team.model';

@Injectable({
  providedIn: 'root'
})
export class AdminService {
public baseUrl='https://8080-ffcfaafecf316719931eabbabbfone.premiumproject.examly.io';
  constructor(private httpClient:HttpClient) { }
  public getTeams():Observable<Team[]>{
    return this.httpClient.get<Team[]>(this.baseUrl+'/api/team');
  }
  public createTeam(team:Team):Observable<any>{
    return this.httpClient.post(this.baseUrl+'/api/team',team);
  }

  public updateTeam(teamId:number,team:Team):Observable<any>{
    return this.httpClient.put(this.baseUrl+'/api/team/'+teamId,team);
  }

  public deleteTeam(teamId:number):Observable<any>{
    return this.httpClient.delete(this.baseUrl+'/api/team/'+teamId);
  }

  public getPlayers():Observable<any>{
    return this.httpClient.get(this.baseUrl+'/api/player');
  }

  public createPlayer(player:Player):Observable<any>{
    return this.httpClient.post(this.baseUrl+'/api/player',player);
  }

  public updatePlayer(playerId:number,player:Player):Observable<any>{
    return this.httpClient.put(this.baseUrl+'/api/player/'+playerId,player);
  }

  public deletePlayer(playerId:number):Observable<any>{
    return this.httpClient.delete(this.baseUrl+'/api/player/'+playerId);
  }

}
