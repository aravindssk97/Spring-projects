import { Component, OnInit } from '@angular/core';
import { AdminService } from '../services/admin.service';
import { Team } from 'src/models/team.model';
import { FormBuilder, FormGroup, Validators, AbstractControl, ValidationErrors } from '@angular/forms';

@Component({
  selector: 'app-team',
  templateUrl: './team.component.html',
  styleUrls: ['./team.component.css']
})
export class TeamComponent implements OnInit {

  teams: Team[] = [];
  newTeam: Team = { name: '', maximumBudget: 1 };
  editedTeam: Team = null;
  editedTeamId: number = null;
  teamAddForm: FormGroup;
  teamEditForm: FormGroup;

  constructor(private adminService: AdminService, private fb: FormBuilder) { }

  ngOnInit(): void {
    this.teamAddForm = this.fb.group({
      name: ['', [Validators.required, this.noSpaceValidator]],
      maximumBudget: [1, [Validators.required, Validators.min(0), this.noDecimalValidator]]
    });

    this.teamEditForm = this.fb.group({
      name: ['', [Validators.required, this.noSpaceValidator]],
      maximumBudget: ['', [Validators.required, Validators.min(0), this.noDecimalValidator]]
    });

    this.getTeams();
  }


  noSpaceValidator(control: AbstractControl): ValidationErrors | null {
    if (control.value && control.value.indexOf(' ') >= 0) {
      return { noSpace: true };
    }
    return null;
  }


  noDecimalValidator(control: AbstractControl): ValidationErrors | null {
    if (control.value && !Number.isInteger(control.value)) {
      return { noDecimal: true };
    }
    return null;
  }

  get maxBidStatus(): string {
    this.newTeam = this.teamAddForm.value;
    if (this.newTeam.maximumBudget && this.newTeam.maximumBudget < 1000) {
      return 'Too Low';
    } else if (this.newTeam.maximumBudget && this.newTeam.maximumBudget < 5000) {
      return 'Low';
    } else {
      return 'Good Budget';
    }
  }

  // Team methods
  getTeams() {
    this.adminService.getTeams().subscribe(arr => {
      this.teams = arr;
    });
  }

  createTeam() {
    this.adminService.createTeam(this.teamAddForm.value).subscribe(arr => {
      this.getTeams();
      this.teamAddForm.reset();
    });
  }

  deleteTeam(teamId: number) {
    this.adminService.deleteTeam(teamId).subscribe(data => {
      this.getTeams();
    });
  }

  editTeam(team: Team) {
    this.editedTeam = { ...team };
    this.editedTeamId = team.id;
    this.teamEditForm.patchValue({ ...team });
  }

  updateTeam() {
    this.adminService.updateTeam(this.editedTeamId, this.teamEditForm.value).subscribe(data => {
      this.editedTeam = null;
      this.getTeams();
    });
  }

  onCancelEditTeam(): void {
    this.editedTeam = null;
  }
}
