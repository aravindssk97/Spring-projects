import { Component, EventEmitter, Input, Output } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Player } from 'src/models/player.model';
import { AdminService } from '../services/admin.service';



@Component({
  selector: 'app-player',
  templateUrl: './player.component.html',
  styleUrls: ['./player.component.css']
})

export class PlayerComponent{

  players:Player[]=[];
  newPlayer: Player={name:'', age: 0, category:'',biddingPrice:0};
  editedPlayer:Player = null;
  editedPlayerId:number=null;
  playerAddForm: FormGroup
  playerEditForm: FormGroup

  constructor(private adminService: AdminService, private fb: FormBuilder) { }

  ngOnInit(): void {
    this.getPlayer();

    this.playerAddForm=this.fb.group({
      name:['', Validators.required],
      age:[null, Validators.required],
      category:['', Validators.required],
      biddingPrice:[1, Validators.required]
    })

    this.playerEditForm=this.fb.group({
      name:['', Validators.required],
      age:[null, Validators.required],
      category:['', Validators.required],
      biddingPrice:[null, Validators.required]
    })
  }

  get biddingPriceStatus():string{
    this.newPlayer=this.playerAddForm.value    
    if(this.newPlayer.biddingPrice==0){
      return"0";
    } else if(this.newPlayer.biddingPrice && this.newPlayer.biddingPrice<1000){
      return 'Too Low';
    }else if(this.newPlayer.biddingPrice && this.newPlayer.biddingPrice<5000){
      return'Low';
    }else{
      return'Good bidding';
    }
  }

    getPlayer(){
    this.adminService.getPlayers().subscribe(arr=>{
      this.players=arr;
    });
    }
    
    createPlayer(){
      this.adminService.createPlayer(this.playerAddForm.value).subscribe(arr=>{
        this.getPlayer();
        this.playerAddForm.reset();
      });
    }
    
    deletePlayer(playerId: number){
      this.adminService.deletePlayer(playerId).subscribe(data=>{
        this.getPlayer();
      })
    }
  
    editPlayer(player:Player){
      this.editedPlayer={...player};
      this.editedPlayerId=player.id
      this.playerEditForm.patchValue({...player});
    }
  
    updatePlayer(){
      this.adminService.updatePlayer(this.editedPlayerId, this.playerEditForm.value).subscribe(data=>{
        this.editedPlayer=null;
        this.getPlayer();
      })
    }
  
    onCancelEditPlayer(): void{
      this.editedPlayer=null;
    }
}
